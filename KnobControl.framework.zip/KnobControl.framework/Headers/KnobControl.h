//
//  KnobControl.h
//  KnobControl
//
//  Created by Derick on 15/1/20.
//  Copyright © 2020 DerickProductions. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for KnobControl.
FOUNDATION_EXPORT double KnobControlVersionNumber;

//! Project version string for KnobControl.
FOUNDATION_EXPORT const unsigned char KnobControlVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KnobControl/PublicHeader.h>


